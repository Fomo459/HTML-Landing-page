const nav =()=>{
    const burger = document.querySelector('.burger');
    const nav = document.querySelector('.nav-links');
    const navLinks = document.querySelectorAll('.nav-links li');
    
    
    //Toggle navigation burger
    burger.addEventListener('click', ()=>{
        nav.classList.toggle('nav-active');
        
    //Nav links Annimation 
    navLinks.forEach((link, index)=>{
        link.style.annimation =
        `annimation 0.5s ease forwards ${index / 4 +1.5}s`;
    });

    });
}

nav();